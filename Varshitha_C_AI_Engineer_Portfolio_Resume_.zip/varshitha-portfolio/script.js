const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if (reducedMotion) document.querySelectorAll('.flow-particles').forEach(particles => particles.remove());

// Mobile navigation
const menuToggle = $('#menu-toggle');
const navLinks = $('#nav-links');
menuToggle?.addEventListener('click', () => {
  const open = menuToggle.getAttribute('aria-expanded') === 'true';
  menuToggle.setAttribute('aria-expanded', String(!open));
  menuToggle.setAttribute('aria-label', open ? 'Open navigation menu' : 'Close navigation menu');
  navLinks?.classList.toggle('is-open', !open);
});
navLinks?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  navLinks.classList.remove('is-open');
  menuToggle?.setAttribute('aria-expanded', 'false');
  menuToggle?.setAttribute('aria-label', 'Open navigation menu');
}));

// Active navigation state
const navAnchors = $$('.nav-links a[href^="#"]');
const navTargets = navAnchors.map(link => $(link.getAttribute('href'))).filter(Boolean);
if ('IntersectionObserver' in window) {
  const navObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navAnchors.forEach(link => link.classList.toggle('is-current', link.getAttribute('href') === `#${entry.target.id}`));
      }
    });
  }, { rootMargin: '-25% 0px -60% 0px', threshold: 0 });
  navTargets.forEach(target => navObserver.observe(target));
}

// Controlled reveals; content remains available when reduced motion is enabled or IO is unavailable.
if (!reducedMotion && 'IntersectionObserver' in window) {
  const revealItems = $$('.section-heading, .about-grid, .expertise-row, .project-feature, .project-wide, .project-split, .workflow-frame, .experience-item, .education-entry, .publication-feature');
  revealItems.forEach((item, i) => {
    item.setAttribute('data-reveal', '');
    item.style.transitionDelay = `${Math.min(i % 4, 3) * 55}ms`;
  });
  document.documentElement.classList.add('reveal-ready');
  const revealObserver = new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-revealed');
      revealObserver.unobserve(entry.target);
    }
  }), { threshold: 0.08, rootMargin: '0px 0px -35px 0px' });
  revealItems.forEach(item => revealObserver.observe(item));
}

// Hero signal constellation annotations
const signalNotes = {
  data: { label: 'SIGNAL NOTE / 01', title: 'Good systems begin with good questions.', copy: 'Start with source quality, task context, and what a useful answer needs to contain.' },
  model: { label: 'SIGNAL NOTE / 02', title: 'A model is one part of the system.', copy: 'Features, retrieval, tools, guardrails, and interfaces shape the experience around the model.' },
  evidence: { label: 'SIGNAL NOTE / 03', title: 'Useful output should be inspectable.', copy: 'Evaluation and source evidence help make system behavior easier to understand and improve.' }
};
$$('[data-signal]').forEach(button => {
  button.setAttribute('aria-pressed', 'false');
  button.addEventListener('click', () => {
    const note = signalNotes[button.dataset.signal];
    if (!note) return;
    $$('[data-signal]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
    $('#signal-tooltip-title').textContent = note.title;
    $('#signal-tooltip-copy').textContent = note.copy;
    $('.tooltip-kicker').textContent = note.label;
    $('#signal-state').textContent = button.dataset.signal.toUpperCase() + ' FOCUS';
  });
});
const signalVisual = $('#signal-visual');
signalVisual?.addEventListener('pointermove', event => {
  if (event.pointerType === 'touch' || reducedMotion) return;
  const bounds = signalVisual.getBoundingClientRect();
  const x = (event.clientX - bounds.left) / bounds.width - 0.5;
  const y = (event.clientY - bounds.top) / bounds.height - 0.5;
  const focus = $('.signal-focus', signalVisual);
  if (focus) focus.style.transform = `translate(${x * 5}px, ${y * 5}px)`;
});
signalVisual?.addEventListener('pointerleave', () => {
  const focus = $('.signal-focus', signalVisual);
  if (focus) focus.style.transform = '';
});

// Project filtering
const filterButtons = $$('.filter-button');
const projectItems = $$('#projects [data-project]');
filterButtons.forEach(button => {
  button.addEventListener('click', () => {
    const filter = button.dataset.filter;
    filterButtons.forEach(item => {
      const active = item === button;
      item.classList.toggle('is-active', active);
      item.setAttribute('aria-pressed', String(active));
    });
    projectItems.forEach(project => {
      project.classList.toggle('is-hidden', filter !== 'all' && project.dataset.category !== filter);
    });
  });
});

// Project details dialog
const projectDetails = {
  rag: {
    title: 'Financial RAG Evaluation and Grounded Answering Agent', subtitle: 'GenAI · Retrieval evaluation · Financial documents',
    description: 'A retrieval-augmented question-answering pipeline over SEC 10-K filings for five banks. It processes 6,549 text and table chunks and combines keyword and dense retrieval with reranking and source-cited answers.',
    metric: 'Hit@5: 0.82 → 0.97 · MRR@5: 0.66 → 0.77 · 34-question retrieval benchmark',
    bullets: ['Compared five retrieval configurations using BM25, dense embeddings, reciprocal rank fusion, and cross-encoder reranking.', 'Added agent checks for numeric verification, calculator use, refusal of investment-advice requests, and unsupported answers.', 'Added 14 automated tests in GitHub Actions and documented latency and evaluation-set limitations.'],
    note: 'Hit@5 and MRR@5 measure evidence retrieval, not end-to-end answer accuracy. The benchmark contains 34 questions, and reranking increases latency; citation correctness and answer faithfulness remain separate evaluation questions.',
    links: [{ url: 'https://github.com/VarshithaChappidi/financial-rag-eval', label: 'Open GitHub repository ↗' }]
  },
  text2sql: {
    title: 'Text-to-SQL Fine-Tuning with QLoRA', subtitle: 'LLM fine-tuning · Code models · Parameter efficiency',
    description: 'Fine-tuned Qwen2.5-Coder-3B-Instruct with 4-bit QLoRA on 5,000 sql-create-context examples using a free Colab T4 GPU, training about 0.96% of model parameters.',
    metric: 'Normalized exact match: 57.0% before training → 77.3% after fine-tuning · 300 held-out questions',
    bullets: ['Used PEFT/QLoRA to fine-tune a 3B code model with a parameter-efficient 4-bit setup.', 'Evaluated on 300 held-out natural-language-to-SQL questions with strict and normalized exact-match scoring.', 'Reviewed formatting mismatches separately from SQL logic errors and documented value-copying and multi-table-join limitations.'],
    note: 'Normalized exact match is a string-based comparison metric; it is not SQL execution accuracy or proof that generated queries return correct results.',
    links: [{ url: 'https://github.com/VarshithaChappidi/text2sql-qlora', label: 'Open GitHub repository ↗' }, { url: 'https://huggingface.co/Varshitha2603/qwen2.5-coder-3b-text2sql-qlora', label: 'View fine-tuned model ↗' }]
  },
  grounded: {
    title: 'Grounded Knowledge Assistant with Hybrid Retrieval', subtitle: 'RAG · Document question answering · Evidence grounding',
    description: 'A runnable document-Q&A MVP combining lexical retrieval, TF-IDF vector-space similarity, reciprocal-rank fusion, source-linked evidence, and evidence-based abstention. The repository also includes a PostgreSQL/pgvector schema as an extension point.',
    bullets: ['Ingest and chunk text documents with stable source metadata.', 'Combine lexical and TF-IDF rankings with reciprocal-rank fusion and return inspectable evidence.', 'Expose ingestion, search, and answer endpoints with FastAPI; run a small labeled retrieval benchmark and Pytest suite.'],
    note: 'The current implementation is an in-memory MVP. PostgreSQL persistence, a production embedding model, LangChain orchestration, and cross-encoder reranking are future extensions; no unreported benchmark improvements are claimed.',
    links: [{ url: 'https://github.com/VarshithaChappidi/Grounded-Knowledge-Assistant-with-Hybrid-Retrieval', label: 'Open GitHub repository ↗' }]
  },
  agent: {
    title: 'Tool-Using Agent Reliability and Evaluation Harness', subtitle: 'Agentic AI · LangGraph · Tool validation and testing',
    description: 'A local LangGraph support-workflow agent using synthetic ticket records and mock service APIs. It validates tool flows, applies bounded retries, drafts proposed actions, and requires human approval before state-changing operations.',
    bullets: ['Use Pydantic schemas and a LangGraph workflow for request classification, ticket lookup, and action drafting.', 'Exercise normal, transient timeout, persistent timeout, malformed response, ambiguous request, and prompt-injection-like scenarios.', 'Report scenario pass rate, timeout recovery, tool errors, and latency, with optional MLflow metric logging.'],
    note: 'The harness uses synthetic tickets and mock APIs; it does not connect to live customer systems or perform real state changes. Evaluation results are functional scenario checks, not production agent-quality measurements.',
    links: [{ url: 'https://github.com/VarshithaChappidi/Tool-Using-Agent-Reliability-and-Evaluation-Harness', label: 'Open GitHub repository ↗' }]
  },
  conversation: {
    title: 'Conversation Intelligence Classification Benchmark', subtitle: 'Conversational NLP · Intent classification · Model evaluation',
    description: 'A benchmark comparing a TF-IDF/logistic-regression baseline with a fine-tuned transformer for support-intent classification on an appropriately licensed public dataset.',
    bullets: ['Compare macro F1, per-class recall, inference latency, and misclassification patterns.', 'Add confidence-based routing so uncertain intent predictions can receive human review.', 'Expose a tested prediction workflow through a FastAPI endpoint.'],
    note: 'No numerical benchmark scores are included in the supplied resume for this project. The portfolio therefore describes evaluation measures without presenting unverified results.',
    links: [{ url: 'https://github.com/VarshithaChappidi/conversation-intelligence-classification-benchmark', label: 'Open GitHub repository ↗' }]
  }
};
const dialog = $('#project-dialog');
const dialogContent = $('#dialog-content');
const closeDialogButton = $('#dialog-close');
let lastFocusedElement = null;
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
}
function openProject(key, trigger) {
  const item = projectDetails[key];
  if (!item || !dialog || !dialogContent) return;
  lastFocusedElement = trigger || document.activeElement;
  const bullets = item.bullets.map(bullet => `<li>${escapeHTML(bullet)}</li>`).join('');
  const metric = item.metric ? `<div class="dialog-metric">${escapeHTML(item.metric)}</div>` : '';
  const links = (item.links || []).map(link => `<a class="dialog-link" href="${link.url}" target="_blank" rel="noopener noreferrer">${escapeHTML(link.label)}</a>`).join(' ');
  const scopeHeading = ['grounded', 'agent', 'conversation'].includes(key) ? 'Project scope' : 'What I worked on';
  dialogContent.innerHTML = `<p class="section-kicker">${escapeHTML(item.subtitle)}</p><h2 id="dialog-title">${escapeHTML(item.title)}</h2><p>${escapeHTML(item.description)}</p>${metric}<h3>${scopeHeading}</h3><ul>${bullets}</ul><h3>Evaluation notes</h3><p>${escapeHTML(item.note)}</p>${links}`;
  if (typeof dialog.showModal === 'function') {
    dialog.showModal();
    closeDialogButton?.focus();
  } else {
    dialog.setAttribute('open', '');
  }
}
$$('[data-open-project]').forEach(button => button.addEventListener('click', () => openProject(button.dataset.openProject, button)));
closeDialogButton?.addEventListener('click', () => dialog?.close());
dialog?.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
dialog?.addEventListener('close', () => lastFocusedElement?.focus());
dialog?.addEventListener('keydown', event => { if (event.key === 'Escape') dialog.close(); });

// RAG exhibit: each stage changes the explanation and miniature source artifact.
const ragStages = {
  documents: { index: 'STEP 01 / SOURCE MATERIAL', title: 'Start with primary documents.', text: 'The pipeline ingests annual-report HTML, extracts relevant sections and tables, and preserves source context for downstream retrieval.', source: 'SOURCE / 01', sourceTitle: '10-K · Risk factors', sourceText: 'A representative filing-section fragment. The local exhibit is a diagram of the workflow, not a live document retrieval session.' },
  chunking: { index: 'STEP 02 / DOCUMENT CHUNKING', title: 'Make long documents retrievable.', text: 'Text and table content are segmented into chunks that can be indexed and matched to a question, with document context retained for evidence inspection.', source: 'SOURCE / CHUNK', sourceTitle: 'Section fragment', sourceText: 'Illustrative chunk: section text or a flattened table segment becomes a candidate unit of evidence.' },
  retrieval: { index: 'STEP 03 / HYBRID RETRIEVAL', title: 'Use two ways to find the signal.', text: 'BM25 captures lexical overlap, while dense retrieval can identify related wording. Company filtering and reciprocal rank fusion help combine candidate lists.', source: 'RETRIEVAL / RRF', sourceTitle: 'Merged candidate list', sourceText: 'The benchmark compares BM25, dense retrieval, reciprocal rank fusion, and cross-encoder reranking over 6,549 chunks and 34 questions.' },
  reranking: { index: 'STEP 04 / CROSS-ENCODER', title: 'Reorder candidates against the question.', text: 'A cross-encoder scores query–passage pairs and promotes stronger evidence. Hit@5 improved from 0.82 to 0.97 and MRR@5 from 0.66 to 0.77; reranking increased latency.', source: 'RERANK / TOP RESULT', sourceTitle: 'Prioritized evidence', sourceText: 'Hit@5 and MRR@5 measure retrieval, not answer accuracy. The 34-question set is small, and reranking increases retrieval latency.' },
  answer: { index: 'STEP 05 / CITED ANSWER', title: 'Keep the response connected to evidence.', text: 'Claude drafts a response using retrieved context. Citation markers make it possible to inspect the source material associated with a claim.', source: 'ANSWER / CITATIONS', sourceTitle: 'Source-linked claim', sourceText: 'Citations indicate where support should be inspected. Citation validity and answer faithfulness require evaluation beyond retrieval metrics.' },
  verification: { index: 'STEP 06 / EVIDENCE VERIFICATION', title: 'Check claims before trusting the output.', text: 'The LangGraph workflow uses numeric verification, calculator use, refusal checks for investment-advice requests, and handling for unsupported answers. Number presence alone does not prove semantic correctness.', source: 'VERIFY / HUMAN REVIEW', sourceTitle: 'Validation boundary', sourceText: 'The numeric verifier is a guardrail, not a proof of semantic correctness. The repository notes that answer faithfulness and citation validation need separate evaluation.' }
};
$$('[data-rag-stage]').forEach(button => {
  const activateStage = () => {
    const key = button.dataset.ragStage;
    const stage = ragStages[key];
    if (!stage) return;
    $$('[data-rag-stage]').forEach(item => {
      const active = item === button;
      item.classList.toggle('is-selected', active);
      item.setAttribute('aria-pressed', String(active));
    });
    $('#rag-detail-label').textContent = stage.index;
    $('#rag-detail-title').textContent = stage.title;
    $('#rag-detail-text').textContent = stage.text;
    $('#rag-detail-visual').dataset.stage = key;
    $('#source-preview .mono-label').textContent = stage.source;
    $('#source-preview strong').textContent = stage.sourceTitle;
    $('#source-preview p').textContent = stage.sourceText;
  };
  button.addEventListener('click', activateStage);
  button.addEventListener('focus', activateStage);
});
const citationContent = {
  sourceA: { label: 'SOURCE / CITATION [1]', title: 'Annual report section', text: 'An illustrative citation target representing a relevant filing section. In a real answer, the source fragment and citation location must be checked against the filed document.' },
  sourceB: { label: 'SOURCE / CITATION [2]', title: 'Financial table or disclosure', text: 'A second illustrative source target. The project specifically handles section text and table-derived evidence; numeric presence checks are not a complete claim verifier.' }
};
$$('[data-citation]').forEach(button => button.addEventListener('click', () => {
  const item = citationContent[button.dataset.citation];
  if (!item) return;
  $$('[data-citation]').forEach(other => {
    const active = other === button;
    other.setAttribute('aria-pressed', String(active));
  });
  $('#source-preview .mono-label').textContent = item.label;
  $('#source-preview strong').textContent = item.title;
  $('#source-preview p').textContent = item.text;
}));

// Interactive engineering workflow
const workflowDetails = {
  data: { index: 'STAGE 01 / INPUT', title: 'Start with the right source.', copy: 'Understand the task, data origin, and context before choosing a model. Document Q&A may begin with annual-report filings; prediction may begin with transaction or borrower records.', tools: 'SQL · HTML parsing · Source documents', href: '#project-rag' },
  prep: { index: 'STAGE 02 / PREPARATION', title: 'Make the data dependable.', copy: 'Clean inconsistent records, validate fields, and segment documents with enough context for downstream retrieval or modeling.', tools: 'Pandas · Spark · Data validation · Chunking', href: '#project-grounded' },
  features: { index: 'STAGE 03 / REPRESENTATION', title: 'Choose a useful representation.', copy: 'Engineer predictive features from structured records or create embeddings that represent the meaning of text for retrieval.', tools: 'Feature engineering · Embeddings · Vector indexes', href: '#project-conversation' },
  model: { index: 'STAGE 04 / MODEL OR RETRIEVAL', title: 'Predict, retrieve, or generate.', copy: 'Select the technique to fit the task: classification for risk, retrieval and reranking for document evidence, or LLMs for contextual language output.', tools: 'Scikit-learn · BM25 · Dense search · RRF · LLMs', href: '#project-rag' },
  evaluate: { index: 'STAGE 05 / EVALUATION', title: 'Measure what matters for the task.', copy: 'Use task-appropriate metrics and failure analysis. Retrieval Hit@5, classification precision/recall, and answer faithfulness measure different things.', tools: 'Hit@5 · Precision / recall · F1 · Error analysis', href: '#project-agent' },
  apply: { index: 'STAGE 06 / APPLICATION', title: 'Make capability useful in context.', copy: 'Integrate model outputs into interfaces and services with validation, clear limits, and human oversight where appropriate.', tools: 'FastAPI · Microservices · LangGraph · Review workflows', href: '#experience' }
};
const workflowSteps = $$('.workflow-step');
workflowSteps.forEach((button, index) => button.addEventListener('click', () => {
  const stage = workflowDetails[button.dataset.workflowStep];
  if (!stage) return;
  workflowSteps.forEach(item => {
    const active = item === button;
    item.classList.toggle('is-active', active);
    item.setAttribute('aria-pressed', String(active));
  });
  $('#workflow-detail-index').textContent = stage.index;
  $('#workflow-detail-title').textContent = stage.title;
  $('#workflow-detail-copy').textContent = stage.copy;
  $('#workflow-detail-tools').textContent = stage.tools;
  $('#workflow-project-link').href = stage.href;
  const path = $('#workflow-path-active');
  if (path) {
    const length = 1000;
    const progress = (index + 1) / workflowSteps.length;
    path.style.strokeDashoffset = String(length * (1 - progress));
  }
}));

// Footer year
const year = $('#year');
if (year) year.textContent = new Date().getFullYear();
