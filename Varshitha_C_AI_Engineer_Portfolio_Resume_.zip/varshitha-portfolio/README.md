# Varshitha Chappidi — The Signal Index

A responsive, editorial-style AI/ML portfolio built with plain HTML, CSS, and JavaScript. The visual identity uses a warm ivory canvas, cobalt blue, restrained coral and lime accents, monospace research annotations, custom SVG diagrams, and interactive project exhibits.

## Preview locally

1. Extract the project folder.
2. Open `index.html` in a modern browser. For the closest match to a hosted static site, you may also serve the folder with a local web server.
3. Internet access is only used for the optional Google Fonts stylesheet. If it is unavailable, the site falls back to system sans-serif and monospace fonts.

## What's included

- Responsive navigation with active-section feedback and a mobile menu.
- Animated, light-background SVG hero visualization with interactive data/model/evidence notes.
- Skills and tooling laid out as an editorial ledger.
- Four project-specific visualizations:
  - Financial RAG pipeline with six interactive stages, citation/source inspection, and the benchmark metric's limitation called out.
  - Financial analytics workbench with a labeled illustrative spending chart, sample transactions/categories, tooltips, and category selection.
  - Loan-risk feature-space scatter plot with interactive sample points and precision/recall explainers.
  - Product semantic-map interaction backed by predefined example concepts, not a live embedding model.
- Interactive engineering workflow path.
- Professional experience aligned to the latest resume (Scale / Frontier Agents Engineer (Applied AI), Observe.AI), education, and the IEEE publication.
- Project detail dialog, filters, keyboard-focus states, reduced-motion support, responsive layouts, and contact links.

## Technical details

- No frontend framework or runtime dependency is required.
- Custom diagrams and charts are authored with inline SVG and native HTML controls.
- Illustrative chart points, finance data, classification points, semantic relationships, and answer/source snippets are local examples. They are not live API results, production outputs, or real customer data.
- The RAG Hit@5 result of 0.97 is identified as retrieval performance on a 34-question benchmark, not end-to-end answer accuracy. The latency trade-off and separate answer-faithfulness/citation-validation limits remain stated.
- Public GitHub links are included for all five featured projects. Project cards distinguish completed implementation details from future extensions and do not claim unreported benchmark results.

## Deploy to Netlify

1. Sign in to Netlify.
2. Drag the extracted `varshitha-portfolio` folder into Netlify Drop or create a new site and deploy the folder as a static site.
3. Use the public `.netlify.app` URL when sharing the portfolio.
4. Confirm the site's visitor visibility is public if Netlify prompts for access settings.

## Before publishing

- Verify all role descriptions, employer associations, and resume-reported outcomes are correct and appropriate to share publicly.
- Add a current resume PDF and any additional public project/demo URLs where available.
- Keep all visual demo-data disclaimers intact unless replacing the examples with genuinely evaluated data and an explicitly connected backend.

© Varshitha C
